const client = require("../../index");
const Discord = require('discord.js');

client.on("ready", async () =>{ 
  console.log(`💻 [App] Estou on-line!`);
  await client.guilds.fetch().then(guilds => {
    console.log(`💻 [App] ${guilds.size} usuários.`)
  });
  client.user.setPresence({ activities: [{ name: "empatia.", type: Discord.ActivityType.Streaming, url: `https://www.twitch.tv/newlojabrasil` }],
  status: 'dnd',
  });

  /*
  client.application.commands.fetch('1064652331368583280').then( (command) => {console.log(`[Slash] ${command.name} localizado.`); command.delete(); console.log(`[Slash] ${command.name} deletado`)}).catch(console.error);
  */
})