const client = require('../../index.js');
const Discord = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');
const { QuickDB } = require('quick.db');
const db = new QuickDB();
const fs = require('fs');
let Channel;
let Role;

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === 'Saida') { let Modal_Saida = new Discord.ModalBuilder().setCustomId('Modal_Saida').setTitle('Canal de Saída');
        const SaidaModal = new Discord.TextInputBuilder().setCustomId('SaidaModal').setLabel("Qual o ID do canal de saídas?").setStyle(Discord.TextInputStyle.Short).setMinLength(18).setMaxLength(19).setPlaceholder('Exemplo: 012345678910111213').setRequired(true);
        const firstActionRow = new Discord.ActionRowBuilder().addComponents(SaidaModal);
        Modal_Saida.addComponents(firstActionRow); interaction.showModal(Modal_Saida);
        };
        if (interaction.customId === 'finalizar') { interaction.deferUpdate(); setTimeout(() => { interaction.channel.delete().catch(() => console.log('😵 [Erro] Canal deletado pelo autor.')); }, 5000); }
        if (interaction.customId === 'Categoria') { let Modal_Categoria = new Discord.ModalBuilder().setCustomId('Modal_Categoria').setTitle('Categoria dos Tickets');
            const CategoriaModal = new Discord.TextInputBuilder().setCustomId('CategoriaModal').setLabel("Qual o ID da nova categoria?").setStyle(Discord.TextInputStyle.Short).setMinLength(18).setMaxLength(19).setPlaceholder('Exemplo: 012345678910111213').setRequired(true);
            const firstActionRow = new Discord.ActionRowBuilder().addComponents(CategoriaModal);
            Modal_Categoria.addComponents(firstActionRow); interaction.showModal(Modal_Categoria);
        };
        if (interaction.customId === 'concluir_thread') {
            if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
            let Membro = interaction.guild.members.cache.get(`${interaction.channel.topic}`);
            let ConcluirEmbed = new Discord.EmbedBuilder()
            .setAuthor({ name: `${Membro.user.tag} (${Membro.id})`, iconURL: Membro.displayAvatarURL() })
            .setTitle('Ticket finalizado')
            .setColor('0x58f48c')
            .setDescription('Seu ticket foi dado como concluído pela nossa equipe. Caso seu tópico não tenha sido resolvido, utilize o comando novamente.\n\nConsidere deixar sua avaliação de nosso servidor, cada feedback nos incentiva a melhorar as suas experiências conosco.')
            .addFields(
                {
                    name: "Apelido",
                    value: `${interaction.channel.name}`,
                    inline: true
                },
                {
                    name: "Criou",
                    value: `<t:${Math.floor(interaction.channel.lastPinTimestamp/1000)}:R>`,
                    inline: true
                }
            );
            Membro.send({ embeds: [ConcluirEmbed] }).catch(() => console.log('😵 [Erro] Autor da thread está impossibilitado de receber mensagens privadas.'));
            interaction.deferUpdate();
            setTimeout(() => { interaction.channel.delete().catch(() => console.log('😵 [Erro] Canal deletado pelo autor.'));
            }, 5000);
        };
        if (interaction.customId === 'bloquear_membro') { if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
            interaction.channel.permissionOverwrites.create(interaction.channel.topic, { ViewChannel: false });
            interaction.reply({ content: "Autor do ticket removido com sucesso!", ephemeral: true })
            setTimeout(() => { interaction.deleteReply();
            }, 5000);
        };
        if (interaction.customId === 'editar_nome') { if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
            interaction.reply({ content: "Qual será o novo nome do ticket?", ephemeral: true });
            const filter = msg => msg.author.id === interaction.user.id;
            const collector = interaction.channel.createMessageCollector({ filter, limit: 1 });
            collector.on('collect', m => { collector.stop();
                interaction.editReply({ content: `Ticket modificado com sucesso!`, ephemeral: true });
                interaction.channel.setName(`${m.content}`);
                m.delete().catch(() => console.log('😵 [Erro] Canal deletado pelo autor.'));
                setTimeout(() => { interaction.deleteReply();
                }, 5000);
            });
        };
        if (interaction.customId === 'adicionar_participantes') { if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
            interaction.reply({ content: "Mencione o usuário na qual será adicionado no ticket.", ephemeral: true });
            const filter = msg => msg.author.id === interaction.user.id;
            const collector = interaction.channel.createMessageCollector({ filter, limit: 1 });
            collector.on('collect', m => { collector.stop();
                interaction.channel.permissionOverwrites.create(m.content.substring(2).slice(0,-1), { ViewChannel: true, SendMessages: true, AttachFiles: true }).catch(() => { return interaction.editReply({ content: `Mencione um usuário válido!`, ephemeral: true }); })
                interaction.editReply({ content: `Usuário adicionado com sucesso!`, ephemeral: true });
                m.delete().catch(() => console.log('😵 [Erro] Canal deletado pelo autor.'));
                setTimeout(() => { interaction.deleteReply();
                }, 5000);
            });
        };
        if (interaction.customId === 'colocar_em_espera') { if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
            let Membro = interaction.guild.members.cache.get(`${interaction.channel.topic}`);
            let EsperaEmbed = new Discord.EmbedBuilder().setTitle('Ticket em espera').setColor('0xffe45c').setDescription('Seu ticket foi respondida pela nossa equipe. Seja breve em sua resposta para obter um rápido atendimento.\n\nConsidere levar em conta o nosso horário expediente, fora dele tempos de respostas costumam ser mais longos.')
            .setAuthor({ name: `${Membro.user.tag} (${Membro.id})`, iconURL: Membro.displayAvatarURL() })
            .addFields(
                {
                    name: "Apelido",
                    value: `${interaction.channel.name}`,
                    inline: true
                },
                {
                    name: "Criou",
                    value: `<t:${Math.floor(interaction.channel.lastPinTimestamp/1000)}:R>`,
                    inline: true
                }
            );
            Membro.send({ embeds: [EsperaEmbed] }).catch(() => console.log('😵 [Erro] Autor da thread está impossibilitado de receber mensagens privadas.'));
            interaction.deferUpdate();
        };
        if (interaction.customId === 'transcript') { let Arquivo = await discordTranscripts.createTranscript(interaction.channel, { returnType: 'buffer', poweredBy: false });
            fs.writeFileSync(__dirname + `/../../Public/Transcripts/${interaction.channelId}.html`, Arquivo, 'utf8');
            let ButtonTranscript = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setURL(`https://meyhelper.squareweb.app/Transcripts/${interaction.channelId}.html`)
                .setLabel('Visualizar transcrição')
                .setStyle(Discord.ButtonStyle.Link)
            );
            interaction.reply({ content: "Foi salvo um arquivo contendo todo o histórico deste canal, mantenha-o em um local seguro.", components: [ButtonTranscript], ephemeral: true });
        };
    }
    
    if(interaction.isModalSubmit()) {
        if (interaction.customId === 'ThreadModal') { interaction.deferReply({ ephemeral: true }).then(async () => { let Channel = interaction.guild.channels.cache.find(channel => channel.name === `ticket-${interaction.user.username.toLowerCase()}`);
                if (Channel != undefined) return interaction.editReply({ content: 'Você já possui um ticket em aberto.', ephemeral: true });
                let Categoria = await db.get(`${interaction.guild.id}.parent`);
                Categoria = interaction.guild.channels.cache.get(`${Categoria}`);
                function Deletar() { db.delete(`${interaction.guild.id}.parent`);
                    let EmbedErro = new Discord.EmbedBuilder().setTitle('Erro detectado').setDescription('Você precisa configurar este comando antes de usá-lo.').setColor('0xf04444').addFields(
                        {
                            name: "Identificação",
                            value: "MISSING_CHANNEL"
                        }
                    );
                    return interaction.editReply({ embeds: [EmbedErro], ephemeral: true });
                };
                try { interaction.guild.channels.create({
                        name: `ticket-${interaction.user.username.toLowerCase()}`,
                        type : Discord.ChannelType.GuildText,
                        parent: `${Categoria.id}`,
                        permissionOverwrites : [
                            {
                                id : interaction.guild.id,
                                deny : ['ViewChannel']
                            },
                            {
                                id : interaction.user.id,
                                allow : ['ViewChannel', 'SendMessages', 'AttachFiles']
                            }
                        ]
                    }).then(channel => { const ObjetivoModal = interaction.fields.getTextInputValue('ObjetivoModal');
                        const DetalhesModal = interaction.fields.getTextInputValue('DetalhesModal');
                        let EmbedChannel = new Discord.EmbedBuilder()
                        .setDescription(`\`\`\`${DetalhesModal}\`\`\``).setAuthor({ name: `${interaction.user.tag} (${interaction.user.id})`, iconURL: interaction.guild.iconURL() }).setThumbnail(interaction.user.displayAvatarURL()).setColor('Random').addFields(
                            {
                                name: "Motivo",
                                value: ObjetivoModal,
                                inline: true
                            }
                        );
                        let ButtonChannel = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder().setCustomId('finalizar').setLabel('Fechar ticket').setStyle(Discord.ButtonStyle.Danger),
                            new Discord.ButtonBuilder().setCustomId('transcript').setLabel('Transcrever').setStyle(Discord.ButtonStyle.Primary)
                        );
                        let ButtonMods = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder().setEmoji('✔️').setCustomId('concluir_thread').setStyle(Discord.ButtonStyle.Success),
                            new Discord.ButtonBuilder().setEmoji('🔒').setCustomId('bloquear_membro').setStyle(Discord.ButtonStyle.Danger),
                            new Discord.ButtonBuilder().setEmoji('✏️').setCustomId('editar_nome').setStyle(Discord.ButtonStyle.Primary),
                            new Discord.ButtonBuilder().setEmoji('➕').setCustomId('adicionar_participantes').setStyle(Discord.ButtonStyle.Success),     
                            new Discord.ButtonBuilder().setEmoji('💤').setCustomId('colocar_em_espera').setStyle(Discord.ButtonStyle.Secondary)
                        );
                        channel.send({ content: `${interaction.user}`, embeds: [EmbedChannel], components: [ButtonMods, ButtonChannel] }).then(async (msg) => { let Channel = interaction.guild.channels.cache.find(channel => channel.name === `ticket-${interaction.user.username.toLowerCase()}`);
                            let fetchMessages = await Channel.messages.fetch({ after: 1, limit: 1, });
                            AtalhoThread = await fetchMessages.first();
                            let AtalhoButton = new Discord.ActionRowBuilder().addComponents(
                                new Discord.ButtonBuilder().setURL(`${AtalhoThread.url}`).setStyle(Discord.ButtonStyle.Link).setLabel('Atalho ticket')
                            );
                            let Embed = new Discord.EmbedBuilder().setDescription('Seu ticket foi aberto com sucesso!').setColor('0x58f48c').setAuthor({ name: `${interaction.user.tag} (${interaction.user.id})`, iconURL: interaction.user.displayAvatarURL() });
                            interaction.editReply({ embeds: [Embed], components: [AtalhoButton], ephemeral: true });
                            channel.setTopic(`${interaction.user.id}`);
                            msg.pin();
                            let LogsID = await db.get(`${interaction.guild.id}.logs`);
                            ChannelLogs = interaction.guild.channels.cache.get(`${LogsID}`);
                            if (!ChannelLogs) return;
                            let EmbedLogs = new Discord.EmbedBuilder().setColor('Random').setThumbnail(interaction.user.displayAvatarURL()).setTitle('Novo ticket aberto') .addFields(
                                {
                                    name: "Autor",
                                    value: `${interaction.user} (${interaction.user.id})`
                                },
                                {
                                    name: "Apelido",
                                    value: `ticket-${interaction.user.username.toLowerCase()}`
                                },
                                {
                                    name: "Criou",
                                    value: `<t:${Math.floor(Date.now()/1000)}:R>`
                                }
                            );
                            ChannelLogs.send({ embeds: [EmbedLogs] })
                        })
                        setTimeout(function() { channel.permissionOverwrites.create(interaction.user.id, { ViewChannel: true }); }, 1000);
                        const DeleteChannel = setTimeout(() => { let Membro = interaction.guild.members.cache.get(`${channel.topic}`);
                            let ExpiradoEmbed = new Discord.EmbedBuilder().setAuthor({ name: `${Membro.user.tag} (${Membro.id})`, iconURL: Membro.displayAvatarURL() }).setTitle('Inatividade detectada').setColor('0xf04444').setDescription('Seu ticket foi deletado, pois detectamos nenhum conteúdo enviado por você nela.\n\nCaso seu tópico não tenha sido resolvido, utilize o comando novamente e busque interagir com seu ticket nos próximos 10 minutos após iniciá-la.').addFields(
                                {
                                    name: "Apelido",
                                    value: `${channel.name}`,
                                    inline: true
                                },
                                {
                                    name: "Criou",
                                    value: `<t:${Math.floor(channel.lastPinTimestamp/1000)}:R>`,
                                    inline: true
                                }
                            );
                            Membro.send({ embeds: [ExpiradoEmbed] })
                            channel.delete().catch(() => console.log('😵 [Erro] Canal deletado pelo autor.'));
                        }, 600000);
                        const filter = msg => msg.author.id === interaction.user.id;
                        const collector = channel.createMessageCollector({ filter, time: 600000 });
                        collector.on('collect', () => { return clearTimeout(DeleteChannel); });
                    });
                } catch { Deletar(); }
            })
        }
        if (interaction.customId ===  'AnuncioModal') { const Title = interaction.fields.getTextInputValue('TitleEmbed');
            const Description = interaction.fields.getTextInputValue('DescriptionEmbed');
            const Attachment = interaction.fields.getTextInputValue('ImageEmbed');
            const Color = interaction.fields.getTextInputValue('ColorEmbed');
            let Content = " ";
            if(!Channel) return interaction.reply({ content: "Um erro ocorreu, tente preencher o formulário corretamente!", ephemeral: true });
            let Embed = new Discord.EmbedBuilder().setColor('Random').setTitle(`${Title}`).setDescription(`${Description}\n\n*Enviado por ${interaction.user}*`);
            if (Attachment) { try { Embed.setImage(`${Attachment}`); } catch (error) { return interaction.reply({ content: "Um erro ocorreu, tente preencher o formulário corretamente!", ephemeral: true }); } };
            if (Role) { Content = Role; }
            if (Color) { try { Embed.setColor(`${Color.charAt().toUpperCase()+Color.slice(1).toLowerCase()}`); } catch (error) { return interaction.reply({ content: "Um erro ocorreu, tente preencher o formulário corretamente!", ephemeral: true }); } };
            try { Channel.send({ content: `${Content}`, embeds: [Embed] }); } catch { return interaction.reply({ content: "Um erro ocorreu, tente preencher o formulário corretamente!", ephemeral: true }); }
            interaction.reply({ content: `Anúncio enviado com sucesso!`, ephemeral: true });
            return setTimeout(() => { interaction.deleteReply(); }, 5000);
        }
    }

    if(interaction.type === Discord.InteractionType.ApplicationCommand) {
        if (interaction.commandName === 'ticket') { let Categoria = await db.get(`${interaction.guild.id}.parent`);
            let EmbedErro = new Discord.EmbedBuilder().setTitle('Erro detectado').setDescription('Você precisa configurar este comando antes de usá-lo.').setColor('0xf04444')
            .addFields(
                {
                    name: "Identificação",
                    value: "MISSING_CHANNEL"
                }
            );
            if (!Categoria) return interaction.reply({ embeds: [EmbedErro], ephemeral: true });
            let Selecionado = interaction.options.getString("motivo");

            const ThreadModal = new Discord.ModalBuilder().setCustomId('ThreadModal').setTitle('Iniciar um ticket');
            const ObjetivoModal = new Discord.TextInputBuilder().setCustomId('ObjetivoModal').setLabel("Qual o motivo deste ticket?").setValue(`${Selecionado}`).setStyle(Discord.TextInputStyle.Short).setMinLength(2).setMaxLength(32).setRequired(true);
            const DetalhesModal = new Discord.TextInputBuilder().setCustomId('DetalhesModal').setLabel("Conte-nos sua história.").setPlaceholder("Exemplo: Utilizei um comando e nada aconteceu.").setStyle(Discord.TextInputStyle.Paragraph).setMinLength(10).setMaxLength(1024).setRequired(true);

            const firstActionRow = new Discord.ActionRowBuilder().addComponents(ObjetivoModal);
            const secondActionRow = new Discord.ActionRowBuilder().addComponents(DetalhesModal);

            ThreadModal.addComponents(firstActionRow, secondActionRow);
            interaction.showModal(ThreadModal);
	    }
        if(interaction.commandName === 'anúncio') { Channel = interaction.options.getChannel('canal');
            Role = interaction.options.getRole('ping');
        };
    }
})