const client = require("../../index");
const { QuickDB } = require('quick.db');
const db = new QuickDB();

client.on('guildMemberRemove', async member => { let CanalID = await db.get(`${member.guild.id}.leave`);
    let Channel = member.guild.channels.cache.get(CanalID);
    if (!Channel) return;
    Channel.send({ content: `<a:HH_Dyno_Crying:1065420273014276176> ${member} saiu do servidor.` });
});