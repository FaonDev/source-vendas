const client = require("../../index");
const Discord = require('discord.js')

client.on('guildCreate', async guild => {
    let Fundador = guild.members.cache.get(guild.ownerId);
    Fundador.send({ content: `<a:a_dyno_yes:1065419933166612500> Olá, ${Fundador}.\nFui recém adicionada, caso haja quaisquer dúvidas, venha até o meu cantinho saná-las.\n↳ https://discord.gg/YHBg9YVDkY` })
});