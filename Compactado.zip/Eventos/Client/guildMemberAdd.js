const client = require("../../index");
const { QuickDB } = require('quick.db');
const Discord = require('discord.js')
const Canvas = require('canvas');
const db = new QuickDB();

client.on('guildMemberAdd', async member => {
    let Welcome = {};

    Welcome.create = Canvas.createCanvas(1024, 500);
    Welcome.context = Welcome.create.getContext('2d');
    Welcome.context.fillStyle = '#ffffff';
    await Canvas.loadImage("https://i.imgur.com/rfeIE4s.jpg").then(async img => {
        Welcome.context.drawImage(img, 0, 0, 1024, 500);
        Welcome.context.beginPath();
        Welcome.context.arc(512, 166, 128, 0, Math.PI * 2, true);
        Welcome.context.stroke();
        Welcome.context.fill();
    });

    let CanalID = await db.get(`${member.guild.id}.join`);
    let Channel = member.guild.channels.cache.get(CanalID);
    if (!Channel) return;
    let canvas = Welcome; canvas.context.font = '42px sans-serif'; canvas.context.textAlign = 'center'; canvas.context.fillText(member.user.tag, 512, 430); canvas.context.beginPath(); canvas.context.arc(512, 166, 119, 0, Math.PI * 2, true); canvas.context.closePath(); canvas.context.clip();
    await Canvas.loadImage(member.user.displayAvatarURL({ extension: 'png', size: 1024 })).then(img => { canvas.context.drawImage(img, 393, 47, 238, 238) });
    let Arquivo = new Discord.AttachmentBuilder(canvas.create.toBuffer(), `arquivo.png`);
    Channel.send({ content: `<a:a_dyno_yes:1065419933166612500> **Boas-vindas,** ${member}!`, files: [Arquivo] });
});