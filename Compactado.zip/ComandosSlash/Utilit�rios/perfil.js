const Discord = require("discord.js")
module.exports = {
    name: "perfil",
    description: "Exibe informações sobre o perfil de um usuário específico.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
      {
        name: "usuário",
        description: "Usuário na qual será exibido.",
        type: 6,
        required: true,
      },
    ],

    run: async (client, interaction) => {
        let Membro = interaction.options.getMember('usuário');
        let Embed = new Discord.EmbedBuilder().setColor('Random').setAuthor({ name: `${Membro.user.username} (${Membro.id})`, iconURL: interaction.guild.iconURL() }).setThumbnail(Membro.displayAvatarURL()).addFields(
            {
                name: "Entrou",
                value: `<t:${Math.floor(Membro.joinedTimestamp/1000)}:R>`,
                inline: false
            },
        );
        return interaction.reply({ embeds: [Embed] });
    }
}