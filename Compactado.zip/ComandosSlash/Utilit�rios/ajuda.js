const Discord = require("discord.js")
module.exports = {
  name: "ajuda",
  description: "Instrui ensinamentos.",
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    let Embed = new Discord.EmbedBuilder().setTitle('🪧 Ajuda da Mey').setDescription('<a:a_dyno_please:1065420281264484372> Olá. Sou a **Mey**, apenas um simples bot para o Discord.\nEu possuo múltiplas funções públicas, nas quais podem ser utilizadas por qualquer um, basta me adicionar.').setThumbnail(client.user.displayAvatarURL()).setColor('Random').addFields(
      {
        name: "Meus comandos",
        value: "\`/addemoji\`, \`/ajuda\`, \`/anúncio\`, \`/avatar\`, \`/cantada\`, \`/configurações\`, \`/dizer\`, \`/imagine\`, \`/info\`, \`/lento\`, \`/limpar\`, \`/perfil\`, \`/reroll\`, \`/senha\`, \`/servidores\`, \`/sorteio\` e \`/ticket\`."
      }
    );

    return interaction.reply({ embeds: [Embed] });
  }
}