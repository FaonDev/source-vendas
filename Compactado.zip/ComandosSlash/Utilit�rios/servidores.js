const Discord = require("discord.js")
module.exports = {
    name: "servidores",
    description: "Veja em quantos servidores eu estou.",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => { await client.guilds.fetch().then(guilds => { interaction.reply({ content: `Estou em ${guilds.size} servidores.`, ephemeral: true }); }); }
}