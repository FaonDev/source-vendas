const client = require('../../index');
const Discord = require("discord.js");
const { QuickDB } = require('quick.db');
const db = new QuickDB();

module.exports = {
  name: "configurações",
  description: "Realiza as configurações básicas.",
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });

    let Options = new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId('ConfigOptions').setPlaceholder('Clique para selecionar uma opção.').addOptions(
      { label: "Utilitários", emoji: "📚", description: "Comandos simples relacionados a mim.", value: "option_one" },
      { label: "Moderação", emoji: "🛠️", description: "Ferramentas administrativas.", value: "option_two" },
      { label: "Tickets", emoji: "🎟️", description: "Configurações básicas do sistema.", value: "option_three" },
    ));

    let Embed = new Discord.EmbedBuilder()
      .setTitle('Painel de configurações')
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
      .setDescription('Altere os padrões desejados e prossiga com sua configuração. Todas estas informações aqui enviadas serão armazenadas em um local seguro.\n\nA qualquer momento você pode atualizá-las, basta utilizar o comando novamente.')
      .setColor('Random');

    await interaction.reply({ embeds: [Embed], components: [Options], ephemeral: true });
    return;
  }
};

client.on('interactionCreate', async (interaction) => {
  /* Comando: /configurações */
  if (interaction.isStringSelectMenu) {
    let Modal = new Discord.ModalBuilder().setTitle('Formulário da Mey');
    const Formulário = new Discord.TextInputBuilder().setCustomId('Formulário').setLabel("Qual o ID dele(a)").setStyle(Discord.TextInputStyle.Short).setMinLength(18).setMaxLength(19).setRequired(true);
    const Conjunto = new Discord.ActionRowBuilder().addComponents(Formulário);
    Modal.addComponents(Conjunto);

    if (interaction.customId === 'ConfigOptions') {
      let Selecionado = interaction.values[0];
      if (Selecionado === 'option_one') {
        let Options = new Discord.ActionRowBuilder().addComponents(
          new Discord.StringSelectMenuBuilder().setCustomId('ConfigOption1').setPlaceholder('Clique para selecionar uma opção.').addOptions(
            { label: "Latência", emoji: "📡", description: "Exibe minha latência atual.", value: "Tempo_Resposta" },
            { label: "Suporte", emoji: "🎧", description: "Envia o convite de nosso servidor de suporte.", value: "Suporte" },
            { label: "Voltar", emoji: "<a:voltar:1068702915230978128>", value: "back" }
          )
        );
        return interaction.update({ components: [Options] });
      };

      if (Selecionado === 'option_two') {
        let Estado_Entrada = 'Desabilitado'; if (await db.get(`${interaction.guild.id}.join`)) Estado_Entrada = 'Habilitado';
        let Estado_Saída = 'Desabilitado'; if (await db.get(`${interaction.guild.id}.leave`)) Estado_Saída = 'Habilitado';

        let Options = new Discord.ActionRowBuilder().addComponents(
          new Discord.StringSelectMenuBuilder().setCustomId('ConfigOption2').setPlaceholder('Clique para selecionar uma opção.').addOptions(
            { label: `Entrada [${Estado_Entrada}]`, emoji: "📈", description: "Exibe um tela de boas-vindas para novos convidados.", value: "Entrada" },
            { label: `Saída [${Estado_Saída}]`, emoji: "📉", description: "Salva registros de um membro na qual foi dissolvido.", value: "Saida" },
            { label: "Voltar", emoji: "<a:voltar:1068702915230978128>", value: "back" }
          )
        );
        return interaction.update({ components: [Options] });
      };

      if (Selecionado === 'option_three') {
        let Estado_Auditoria = 'Desabilitado'; if (await db.get(`${interaction.guild.id}.logs`)) Estado_Auditoria = 'Habilitado';

        let Options = new Discord.ActionRowBuilder().addComponents(
          new Discord.StringSelectMenuBuilder().setCustomId('ConfigOption3').setPlaceholder('Clique para selecionar uma opção.').addOptions(
            { label: "Categoria", emoji: "📂", description: "Categoria na qual os tickets serão armazenados.", value: "Categoria" },
            { label: `Auditoria [${Estado_Auditoria}]`, emoji: "🗃️", description: "Salva registros de um membro ao abrir um ticket.", value: "Registros" },
            { label: "Voltar", emoji: "<a:voltar:1068702915230978128>", value: "back" }
          )
        );
        return interaction.update({ components: [Options] });
      };
    };

    /* Selecionado: Utilitários */
    if (interaction.customId === 'ConfigOption1') {
      let Selecionado = interaction.values[0];
      if (Selecionado === 'Tempo_Resposta') {
        interaction.reply({ content: `Minha latência está em ${client.ws.ping}.`, ephemeral: true });
      };

      if (Selecionado === 'Suporte') {
        interaction.reply({ content: `**Olá,** ${interaction.user}!\n\nQue tal conhecer meu servidor? Além de oferecermos todo o suporte necessário, realizamos giveaways semanais, quem sabe, você pode ser um dos sortudos.\nhttps://discord.gg/YHBg9YVDkY`, ephemeral: true });
      };

      if (Selecionado === 'back') {
        let Options = new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId('ConfigOptions').setPlaceholder('Clique para selecionar uma opção.').addOptions(
          { label: "Utilitários", emoji: "📚", description: "Comandos simples relacionados a mim.", value: "option_one" },
          { label: "Moderação", emoji: "🛠️", description: "Ferramentas administrativas.", value: "option_two" },
          { label: "Tickets", emoji: "🎟️", description: "Configurações básicas do sistema.", value: "option_three" },
        ));
        interaction.update({ components: [Options] });
      };
    };

    /* Selecionado: Moderação */
    if (interaction.customId === 'ConfigOption2') {
      let Selecionado = interaction.values[0];
      if (Selecionado === 'Entrada') {
        Modal.setCustomId('EntradaModal');
        interaction.showModal(Modal);
      };

      if (Selecionado === 'Saida') {
        Modal.setCustomId('SaídaModal');
        interaction.showModal(Modal);
      };

      if (Selecionado === 'back') {
        let Options = new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId('ConfigOptions').setPlaceholder('Clique para selecionar uma opção.').addOptions(
          { label: "Utilitários", emoji: "📚", description: "Comandos simples relacionados a mim.", value: "option_one" },
          { label: "Moderação", emoji: "🛠️", description: "Ferramentas administrativas.", value: "option_two" },
          { label: "Tickets", emoji: "🎟️", description: "Configurações básicas do sistema.", value: "option_three" },
        ));
        interaction.update({ components: [Options] });
      };
    };

    /* Selecionado: Tickets */
    if (interaction.customId === 'ConfigOption3') {
      let Selecionado = interaction.values[0];
      if (Selecionado === 'Categoria') {
        Modal.setCustomId('CategoriaModal');
        interaction.showModal(Modal);
      };

      if (Selecionado === 'Registros') {
        Modal.setCustomId('RegistrosModal');
        interaction.showModal(Modal);
      };

      if (Selecionado === 'back') {
        let Options = new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId('ConfigOptions').setPlaceholder('Clique para selecionar uma opção.').addOptions(
          { label: "Utilitários", emoji: "📚", description: "Comandos simples relacionados a mim.", value: "option_one" },
          { label: "Moderação", emoji: "🛠️", description: "Ferramentas administrativas.", value: "option_two" },
          { label: "Tickets", emoji: "🎟️", description: "Configurações básicas do sistema.", value: "option_three" },
        ));
        interaction.update({ components: [Options] });
      };
    };
  };

  if (interaction.isModalSubmit()) {
    if (interaction.customId === 'RegistrosModal') {
      let Channel = interaction.guild.channels.cache.get(`${interaction.fields.getTextInputValue('Formulário')}`);
      if (!Channel) return interaction.reply({ content: "Insira um canal válido!", ephemeral: true });
      interaction.reply({ content: "Alterações salvas com sucesso!", ephemeral: true });
      await db.set(`${interaction.guild.id}.logs`, Channel.id);
    };

    if (interaction.customId === 'CategoriaModal') {
      let Channel = interaction.guild.channels.cache.get(`${interaction.fields.getTextInputValue('Formulário')}`);
      if (!Channel || Channel.type != 4) return interaction.reply({ content: "Insira uma categoria válida!", ephemeral: true });
      interaction.reply({ content: "Alterações salvas com sucesso!", ephemeral: true });
      await db.set(`${interaction.guild.id}.parent`, Channel.id);
    };

    if (interaction.customId === 'EntradaModal') {
      let Channel = interaction.guild.channels.cache.get(`${interaction.fields.getTextInputValue('Formulário')}`);
      if (!Channel) return interaction.reply({ content: "Insira um canal válido!", ephemeral: true });
      interaction.reply({ content: "Alterações salvas com sucesso!", ephemeral: true });
      await db.set(`${interaction.guild.id}.join`, Channel.id);
    };

    if (interaction.customId === 'SaídaModal') {
      let Channel = interaction.guild.channels.cache.get(`${interaction.fields.getTextInputValue('Formulário')}`);
      if (!Channel) return interaction.reply({ content: "Insira um canal válido!", ephemeral: true });
      interaction.reply({ content: "Alterações salvas com sucesso!", ephemeral: true });
      await db.set(`${interaction.guild.id}.leave`, Channel.id);
    };
  };
});