const Discord = require('discord.js');

module.exports = {
    name: "número",
    description: "Sorteia um entre outros números.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "início",
            description: "Primeiro número.",
            type: 10,
            required: true
        },
        {
            name: "fim",
            description: "Último número.",
            type: 10,
            required: true
        },
        {
            name: "quantidade",
            description: "Quantidade de números a serem selecionados. (Limite: 10)",
            type: 10,
            required: false
        }
    ],

    run: async (client, interaction) => {
        let Início = interaction.options.getNumber("início");
        let Final = interaction.options.getNumber("fim");
        let Quantidade = interaction.options.getNumber("quantidade");
        let Sorteado = Math.floor(Math.random()*(Final-Início)) + Início;

        if (Quantidade.toString().length > 1 || Início >= Final) return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro, preencha as lacunas corretamente.", ephemeral: true });

        if (Quantidade) {
            for (let Vez = 0; Vez < Quantidade-1; Vez++) {
                Sorteado+=`\n${Math.floor(Math.random()*(Final-Início)) + Início}`;
            };
        };

        let Embed = new Discord.EmbedBuilder().setColor('Random').setThumbnail(interaction.user.displayAvatarURL()).setTitle(`${interaction.user.username} sorteou um número`)
        .addFields(
            {
                name: "Escala",
                value: `${Início} a ${Final}`
            },
            {
                name: "Selecionado(s)",
                value: `${Sorteado}`
            },
        );

        return interaction.reply({ embeds: [Embed] });
    }

}