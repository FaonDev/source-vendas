const Discord = require("discord.js")
module.exports = {
  name: "avatar",
  description: "Apresenta o avatar de um usuário específico.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "usuário",
      description: "Usuário na qual será coletado o avatar.",
      type: 6,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    let Membro = interaction.options.getUser('usuário');

    let Embed = new Discord.EmbedBuilder().setColor('Random').setFooter({ text: `Usuário: ${Membro.username}`, iconURL: interaction.guild.iconURL() }).setImage(Membro.displayAvatarURL({ extension: "png", size: 1024 }));
    interaction.reply({ embeds: [Embed] })
  }
}