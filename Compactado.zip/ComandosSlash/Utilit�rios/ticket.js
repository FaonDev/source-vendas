
const Discord = require("discord.js");
const { QuickDB } = require('quick.db');
const db = new QuickDB();

module.exports = {
  name: "ticket",
  description: "Entra em contato direto com a equipe administrativa.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "motivo",
      description: "Descreva o intuito desta solicitação.",
      min_length: 2,
      type: 3,
      required : true,
    },
  ],

  run: async (client, interaction) => {}
}