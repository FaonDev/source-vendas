const Discord = require("discord.js")
const axios = require('axios');
const { emojis } = require("../..");

module.exports = {
    name: "addemoji",
    description: "Salva um emoji personalizado de um servidor para o atual.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "conteúdo",
            description: "Emoji a ser adicionado.",
            type: 3,
            required: true,
        },
        {
            name: "identificação",
            description: "Nome a ser atribuído.",
            type: 3,
            required: true,
        },
    ],

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
        
        let Conteúdo = interaction.options.getString('conteúdo').substring(interaction.options.getString('conteúdo').length - 20).replace(/\D/g, '');
        let Nome = interaction.options.getString('identificação');

        let Tipo = await axios.get(`https://cdn.discordapp.com/emojis/${Conteúdo}.gif`).then(response => {
            if (response) return "gif";
            else return "png";
        }).catch(() => { return "png"; });

        let Emoji = `https://cdn.discordapp.com/emojis/${Conteúdo}.${Tipo}`;

        await interaction.guild.emojis.create({ attachment: Emoji, name: Nome }).then(response => {
            let Embed = new Discord.EmbedBuilder().setThumbnail(Emoji).setColor('Random').setTitle('Emoji adicionado.').addFields(
                {
                    name: "Enviado por",
                    value: `${interaction.user} (${interaction.user.id})`
                },
                {
                name: "Identificação",
                value: `${Nome}`
                }
            );
            return interaction.reply({ embeds: [Embed] });
        }).catch(() => {
            return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro ao processar sua solicitação, reformule-a e tente novamente.", ephemeral: true });
        });
    }
}