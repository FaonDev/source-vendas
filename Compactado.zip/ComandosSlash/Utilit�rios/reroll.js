const Discord = require("discord.js")
const { QuickDB } = require('quick.db');
const db = new QuickDB();

module.exports = {
    name: "reroll",
    description: "Refaça um sorteio já encerrado.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "sorteio",
            description: "Selecione o sorteio desejado.",
            type: 3,
            required: true,
            choices: [
                {name: "Recente", value: "recente"}
            ]
        },
    ],

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });

        let Participantes = await db.get(`${interaction.guild.id}.participants`);
        if (!Participantes) return interaction.reply({ content: "Você realizou nenhum sorteio recentemente.", ephemeral: true });
        let Ganhador = interaction.guild.members.cache.get(Participantes[Math.floor(Math.random()*Participantes.length)]);
        if (interaction.options.getString('sorteio') === 'recente') {
            interaction.reply({ content: `<a:a_dyno_surprise:1065419926568972298> **Parabéns,** ${Ganhador}. Você é o mais novo ganhador do sorteio!` })
        }
    }
}