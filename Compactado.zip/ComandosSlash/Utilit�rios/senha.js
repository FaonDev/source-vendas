const Discord = require('discord.js');
const generator = require('generate-password');

module.exports = {
    name: "senha",
    description: "Gere uma senha instantânea e segura.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "caracteres",
            description: "Tamanho da senha a ser gerada. (Limite: 99)",
            type: 10,
            required: true
        },
    ],

    run: async (client, interaction) => {
        let Caracteres = interaction.options.getNumber("caracteres");
        if (Caracteres.toString().length > 2) return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro, preencha as lacunas corretamente.", ephemeral: true });

        let Senha = generator.generate({
            length: `${Caracteres}`,
            numbers: true
        });

        let Embed = new Discord.EmbedBuilder().setTitle("Solicitação concluída").setColor('Random').setThumbnail(interaction.user.displayAvatarURL()).setFooter({ text: "Apenas você possui acesso a isto, se cuide!", iconURL: client.user.displayAvatarURL() }).setDescription(`\`\`\`${Senha}\`\`\``);

        interaction.reply({ content: "<a:HH_Dyno_Thumbsup:1065420270006972506> Senha elaborada e enviada com sucesso!", ephemeral: true });
        return interaction.user.send({ embeds: [Embed] });
    }

}