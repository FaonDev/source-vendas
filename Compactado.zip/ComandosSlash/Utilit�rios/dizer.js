const Discord = require("discord.js");
const client = require('../../index')

module.exports = {
  name: "dizer",
  description: "Diga algo em um canal específico.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "canal",
      description: "Canal a ser anunciado.",
      type: 7,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
    let Modal = new Discord.ModalBuilder().setTitle('Formulário da Mey').setCustomId('DizerModal')
    const Formulário = new Discord.TextInputBuilder().setCustomId('Formulário').setLabel("O que deseja enviar?").setStyle(Discord.TextInputStyle.Short).setRequired(true);
    const Conjunto = new Discord.ActionRowBuilder().addComponents(Formulário);
    Modal.addComponents(Conjunto);

    return interaction.showModal(Modal)
  }
}

client.on('interactionCreate', async (interaction) => {
  if (interaction.type === Discord.InteractionType.ApplicationCommand) {
    if (interaction.commandName === 'dizer') {
      Channel = interaction.options.getChannel('canal');
    };
  };

  if (!interaction.isModalSubmit) return;
  if (interaction.customId === 'DizerModal') {
    if (!Channel || Channel.type != 0) return interaction.reply({ content: '<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro ao processar sua solicitação, talvez tenha preenchido-a com valores incorretos.', ephemeral: true })
    Channel.send(`${interaction.fields.getTextInputValue('Formulário')}\n\n*Enviado por ${interaction.user}*`);
    interaction.reply({ content: "<a:HH_Dyno_Thumbsup:1065420270006972506> Mensagem dita com sucesso!", ephemeral: true })
  };
});