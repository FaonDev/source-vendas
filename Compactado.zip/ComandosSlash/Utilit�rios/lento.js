const Discord = require("discord.js")
module.exports = {
     name: "lento",
    description: "Altera o fluxo de mensagens em um canal.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
    {
        name: "intervalo",
        description: "Intervalo entre cada mensagem de um usuário.",
        type: 10,
        max_length: 5,
        required: true,
    },
  ],

  run: async (client, interaction) => { if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
    let Tempo = interaction.options.getNumber('intervalo');
    if (Tempo.toString().length > 5) return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro, preencha as lacunas corretamente.", ephemeral: true });
    interaction.channel.setRateLimitPerUser(Tempo);
    return interaction.reply({ content: "Modo lento aplicado com sucesso!", ephemeral: true });
  }
}