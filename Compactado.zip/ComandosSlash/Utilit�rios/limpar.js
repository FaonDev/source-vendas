const Discord = require("discord.js")
module.exports = {
    name: "limpar",
    description: "Exclui uma quantidade específica de mensagens em um canal.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "quantidade",
            description: "Quantidade de mensagens a serem deletadas.",
            type: 10,
            max_length: 2,
            required: true
        },
    ],

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });
        let Quantidade = interaction.options.getNumber('quantidade');
        if (Quantidade.toString().length > 2) return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro, preencha as lacunas corretamente.", ephemeral: true });
        if (Quantidade < 1) return interaction.reply({ content: '<a:RAGE_dyno_tease:1065420276822724718> Por favor, insira um valor válido!', ephemeral: true })
        interaction.channel.bulkDelete(parseInt(Quantidade)).then(mensagens => { if (mensagens.size < 1) return interaction.reply({ content: `<a:HH_Dyno_Crying:1065420273014276176> Eu não fui capaz de apagar a quantidade especificada, talvez algumas mensagens sejam antigas demais.`, ephemeral: true });
            return interaction.reply({ content: `<a:HH_Dyno_Thumbsup:1065420270006972506> Foram excluídas com sucesso \`${mensagens.size}\` mensagem(s) deste canal.`, ephemeral: true });
        });
    }
}