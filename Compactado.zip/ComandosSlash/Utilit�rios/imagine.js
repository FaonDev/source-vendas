const Discord = require("discord.js");
const Canvas = require('canvas');
const axios = require('axios');

module.exports = {
  name: "imagine",
  description: "Gere uma imagem através de um texto.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "conteúdo",
      description: "Conteúdo da imagem.",
      type: 3,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Comando indisponível, talvez tenha sido desabilitado temporariamente.", ephemeral: true });
    interaction.reply({ content: "<a:a_dyno_sleep:1065420267209375826> Aguarde, estou processando sua solicitação." });
    let prompt = interaction.options.getString('conteúdo');
    axios({
      method: 'post',
      url: 'https://api.openai.com/v1/images/generations',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer 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`
      },
      data: {
        "model": "image-alpha-001",
        "prompt": prompt,
        "num_images": 4,
        "size": "1024x1024",
        "response_format": "url"
      }
    }).then(async response => {
      const canvas = Canvas.createCanvas(1024, 1024);
      const context = canvas.getContext('2d');

      let A = await Canvas.loadImage(response.data.data[0].url);
      let B = await Canvas.loadImage(response.data.data[1].url);
      let C = await Canvas.loadImage(response.data.data[2].url);
      let D = await Canvas.loadImage(response.data.data[3].url);

      context.drawImage(A, 0, 0, 512, 512);
      context.drawImage(B, 512, 0, 512, 512);
      context.drawImage(C, 0, 512, 512, 512);
      context.drawImage(D, 512, 512, 512, 512);

      let Arquivo = new Discord.AttachmentBuilder(canvas.toBuffer());
      let Embed = new Discord.EmbedBuilder().setImage('attachment://file.jpg').setColor('Random').setFooter({ text: `Contexto: ${prompt}`, iconURL: interaction.guild.iconURL() });
      return interaction.editReply({ content: `${interaction.user}`, embeds: [Embed], files: [Arquivo] });
    }).catch(err => { console.log(err); return setTimeout(() => {
      interaction.editReply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro ao processar sua solicitação, talvez ela contenha conteúdo bloqueado." });
    }, 1000); });
  }
};