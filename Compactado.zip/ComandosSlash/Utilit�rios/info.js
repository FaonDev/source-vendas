const Discord = require("discord.js")
module.exports = {
    name: "info",
    description: "Exibe informações sobre o servidor atual.",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        let Embed = new Discord.EmbedBuilder().setColor('Random').setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() }).setThumbnail(interaction.guild.iconURL()).addFields(
            {
                name: "Fundador",
                value: `<@${interaction.guild.ownerId}> (${interaction.guild.ownerId})`,
                inline: false
            },
            {
                name: "Membros",
                value: `${interaction.guild.memberCount}`,
                inline: false
            },
            {
                name: "Entrei",
                value: `<t:${Math.floor(interaction.guild.joinedTimestamp/1000)}:R>`,
                inline: false
            }
        );
        
        return interaction.reply({ embeds: [Embed] });
    }
}