const Discord = require("discord.js");
const { QuickDB } = require('quick.db');
const db = new QuickDB();

module.exports = {
  name: "sorteio",
  description: "Realiza um sorteio em um canal específico.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
        name: "canal",
        description: "Canal na qual o sorteio será realizado.",
        type: 7,
        required: true,
    },
    {
        name: "prêmio",
        description: "Prêmio na qual será sorteado.",
        type: 3,
        required: true,
    },
    {
        name: "descrição",
        description: "Detalhes sobre o prêmio.",
        type: 3,
        required: true,
    },
    {
        name: "tempo",
        description: "Tempo em minutos, na qual o sorteio será finalizado.",
        type: 10,
        required: true,
    },
  ],

  run: async (client, interaction) => {
    let Reactions = [];
    if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });

    let Canal = interaction.options.getChannel('canal');
    let Brinde = interaction.options.getString('prêmio');
    let Detalhes = interaction.options.getString('descrição');
    let Tempo = interaction.options.getNumber('tempo')*60000;
    if (Tempo.toString().length > 5) return interaction.reply({ content: "<a:HH_Dyno_Crying:1065420273014276176> Ocorreu um erro, preencha as lacunas corretamente.", ephemeral: true });
    if (Canal.type === 4) return interaction.reply('Selecione um canal válido!');
    let Embed = new Discord.EmbedBuilder().setColor('Random').setTitle(`🎁 ${Brinde}`).setDescription(`\`\`\`fix\n${Detalhes}\n\`\`\``).setThumbnail(interaction.guild.iconURL()).setFooter({ text: `Para participar, basta reagir abaixo.` }).addFields(
        {
            name: "Realizado por",
            value: `${interaction.user}`
        },
        {
            name: "Tempo restante",
            value: `<t:${Math.floor(Date.now()/1000+Tempo/1000)}:R>`
        }
    );

    Canal.send({ embeds: [Embed] }).then(mensagem => { mensagem.react('🎉');
        const filter = (reaction) => { return reaction.emoji.name === '🎉' };
        const Coletor = mensagem.createReactionCollector({ filter, time: Tempo });
        
        Coletor.on('collect', (reaction, user) => { if(user.id === client.user.id) return;
            if (Reactions.includes(user.id)) return; 
            Reactions.push(user.id);
        });

        setTimeout(() => { if (Reactions.length < 1) return mensagem.reply({ content: "Sorteio cancelado, sem participantes o suficiente." });
            let Ganhador = interaction.guild.members.cache.get(Reactions[Math.floor(Math.random()*Reactions.length)]);
            mensagem.reply({ content: `<a:a_dyno_surprise:1065419926568972298> **Parabéns,** ${Ganhador}. Você ganhou o(a) \`${Brinde}\`.` });
            db.set(`${interaction.guild.id}.participants`, Reactions);
        }, Tempo);
    });

    interaction.reply({ content: "Sorteio iniciado com sucesso!", ephemeral: true });
  }
};