const Discord = require('discord.js');
const client = require('../../index');

let Cantadas = [
    'Não sou arquiteto, mas meu projeto é você, bebê!',
    'Você não é delivery, mas estou esperando você se entregar pra mim.',
    'Você é a peça que faltava no quebra-cabeça da minha vida.',
    'Eu ia dizer uma coisa fofa, mas você me deixou sem palavras.',
    'Seus pais são matemáticos? Porque você é um produto notável.',
    'Meu amor por você é como a fórmula de Pi: irracional e infinito.',
    'Eu tenho certeza que você testou positivo para Belezavírus!',
    'Do que adianta estudar Física, se você não respeita a lei da nossa atração?',
    'Eu sou o amor da sua vida, mas você não está pronto para essa conversa!',
    'Pensava que felicidade começava com F, mas começa com você.',
    'Pronto, já estou aqui. Quais são seus outros 2 desejos?',
    'Meu nome é Arlindo, mas pode me chamar só de lindo, porque o ar eu perdi quando te vi.',
    'Por um acaso você já contou para sua mãe que ela vai ser minha sogra?',
    'Você é tão lindo(a) que, quando nasceu, a sua mãe não te deu apenas à luz, mas a companhia de energia inteira.',
    'Eu nunca pensei que fosse me apaixonar, mas você apareceu pra me provar o contrário. ',
    'Me passa o seu Instagram? Meu pai disse que eu devo seguir o meu sonho.',
    'Eu queria ser grego, mas grego eu não posso ser, porque grego tem várias deusas e minha única deusa é você.',
    'Como eu vou ter um bom dia, se eu não acordei do seu lado?',
    'Talvez você ainda não saiba, mas você é o sol da minha vida, que me ilumina com seu sorriso e me aquece com seu olhar. ',
    'Quantas latas de tinta eu tenho que usar pra pintar um clima entre nós?',
    'Eu sei que você prefere brigadeiro, mas não quer experimentar o meu beijinho?',
    'Você é boa em matemática? Então calcula nós dois juntos.',
    'Eu não sou lanterna, mas posso iluminar sua vida.',
    'Sabe o que combina muito com você? Eu!',
    'Se eu me afogar na tua beleza, tenho direito a respiração boca a boca?',
    'Não sou corretor de imóveis, mas tenho um lugar perfeito para você morar... Meu coração!',
    'Em matéria de amor, você tem doutorado em me conquistar!',
    'Acredite, o nome do amor da sua vida começa com "E", de "Eu".'
];

module.exports = {
    name: "cantada",
    description: "Envie uma cantada para um membro em específico.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "destinatário",
            description: "Usuário na qual receberá sua cantada.",
            type: Discord.ApplicationCommandOptionType.User,
            required: true
        }
    ],

    run: async (client, interaction) => {
        let Embed = new Discord.EmbedBuilder().setColor('Random').setThumbnail(interaction.options.getUser('destinatário').displayAvatarURL()).setTitle('<a:a_dyno_please:1065420281264484372> O amor está no ar...')
        .setFields(
            { name: "Cantada", value: `${Cantadas[Math.floor(Math.random()*Cantadas.length)]}` },
        );

        return interaction.reply({ content: `<a:a_dyno_lonely:1065420285286813827> ${interaction.options.getUser('destinatário')}`, embeds: [Embed] });
    }
};