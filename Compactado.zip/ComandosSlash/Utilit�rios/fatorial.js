const Discord = require('discord.js');

module.exports = {
    name: "fatorial",
    description: "Calcule o fatorial de um número específico.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "número",
            description: "Número a ser calculado.",
            type: 10,
            required: true,
        },
    ],

    run: async (client, interaction) => {
        let Selecionado = interaction.options.getNumber('número');
        if (Selecionado > 100) return interaction.reply({ content: `Limite excedido, tente utilizar um número menor.`, ephemeral: true });
        let Vez, Resultado;
        Vez = Resultado = Selecionado;

        while (Vez > 1) {
            Vez--;
            Resultado = Resultado * Vez;
        };

        return interaction.reply({ content: `Seu fatorial é: ${Resultado}`, ephemeral: true });
    }
};

/*
Créditos: Faon#0633;
Quem sou eu? Sou um simples ser, buscando aperfeiçoar minhas habilidades com JavaScript.
Caso necessite de ajuda extra, não hesitarei em ajudá-lo, conhecimento é gradativo.
*/