const Discord = require("discord.js")

module.exports = {
  name: "anúncio",
  description: "Envie uma Embed em um canal específico.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "canal",
      description: "Canal a ser anunciado.",
      type: 7,
      required: true,
    },
    {
      name: "ping",
      description: "Cargo na qual será mencionado.",
      type: 8,
      required : false,
    }
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: "Você não possui permissão de utilizar este comando.", ephemeral: true });

    const Janela = new Discord.ModalBuilder()
    .setCustomId('AnuncioModal')
    .setTitle('Elabore um anúncio');

    const TitleEmbed = new Discord.TextInputBuilder()
    .setCustomId('TitleEmbed')
    .setLabel("Título da Embed")
    .setStyle(Discord.TextInputStyle.Short)
    .setRequired(true);

    const DescriptionEmbed = new Discord.TextInputBuilder()
    .setCustomId('DescriptionEmbed')
    .setLabel("Descrição da Embed")
    .setStyle(Discord.TextInputStyle.Paragraph)
    .setRequired(true);

    const ImageEmbed = new Discord.TextInputBuilder()
    .setCustomId('ImageEmbed')
    .setLabel("Imagem da Embed")
    .setPlaceholder('Exemplo: https://i.imgur.com/hEy5s4v.png')
    .setStyle(Discord.TextInputStyle.Paragraph)
    .setRequired(false);

    const ColorEmbed = new Discord.TextInputBuilder()
    .setCustomId('ColorEmbed')
    .setLabel("Cor da Embed")
    .setPlaceholder('Exemplo: RED, GREEN, BLUE...')
    .setStyle(Discord.TextInputStyle.Short)
    .setRequired(false);


    const firstActionRow = new Discord.ActionRowBuilder().addComponents(TitleEmbed);
    const secondActionRow = new Discord.ActionRowBuilder().addComponents(DescriptionEmbed);
    const thirdActionRow = new Discord.ActionRowBuilder().addComponents(ImageEmbed);
    const fourthActionRow = new Discord.ActionRowBuilder().addComponents(ColorEmbed);

    Janela.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow);
    return interaction.showModal(Janela);
  }
}